
import numpy as np


def Binning(data, BinAmount):

    if len(data.shape) != 1:
        data2 = np.zeros((data.shape[0]//BinAmount, data.shape[1]))
    else:
        data2 = np.zeros((data.shape[0]//BinAmount))

    for i in range(data.shape[0]//BinAmount):
        data2[i] = np.mean(data[i*BinAmount:(i+1)*BinAmount], axis=0)

    return data2


def Binning_Named(data, BinAmount):

    if len(data.dtype.names) != 1:
        data2 = np.copy(data)[::BinAmount]

    for i in data.dtype.names:
        for j in range(data.shape[0]//BinAmount):
            data2[i][j] = np.mean(data[i][j*BinAmount:(j+1)*BinAmount], axis=0)

    return data2
