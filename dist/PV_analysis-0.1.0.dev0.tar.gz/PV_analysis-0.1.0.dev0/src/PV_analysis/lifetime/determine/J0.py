
import numpy as np
import scipy.constants as const
import matplotlib.pylab as plt


def J0(nxc, tau, W, ni, method, **kwargs):
    '''
    Caculates Jo from the measurement from a lifetime measurement
    inputs:
        nxc: (numpy array)
            number of excess carriers (cm^-3)
        tau: (numpy array)
            lifetime (s)
        W: (float)
            sample thickness (cm)
        ni: (float or numpy array)
            the intrinsic carrier density, or effective intrinsic carrier
            density
        method: (str)
            one of the implimented methods
        kwargs: (optional)
            additional arguments required by some methods
    '''

    method_dic = {
            'kane&swanson': _J0_KaneSwanson,
            'king': _J0_King,
            'Kimmerle_BGN': _J0_Kimmerle,
            'Kimmerle_SRH': _J0_Kimmerle_SRH,
            'Kimmerle_Diffusion': _J0_Kimmerle_Diffusion,
            }

    return method_dic[method](nxc, tau, W, ni, **kwargs)


def _J0_Kimmerle_Diffusion(nxc, tau, W, ni, tau_aug, Ndop, D_ambi):
    # initialise the values
    J0 = _J0_Kimmerle(nxc, tau, W, ni, tau_aug)
    # print (D_ambi)
    for i in range(10):
        tau_SRH = 1./(1./tau - 1./tau_aug -
                      1./(
                          const.e*W*ni**2 / (
                              2 * J0 * (nxc + Ndop)
                              ) +
                          W**2/D_ambi/np.pi**2)
                      )

        tau_SRH = np.mean(tau_SRH)

        tau_cor = 1./ni**2/(1./tau - 1./tau_aug - 1./tau_SRH)
        J0 = _J0_KaneSwanson(nxc, tau_cor, W, 1)

    return J0


def _J0_Kimmerle_SRH(nxc, tau, W, ni, tau_aug, Ndop):
    # initialise the values
    J0 = _J0_Kimmerle(nxc, tau, W, ni, tau_aug)
    for i in range(10):
        tau_SRH = 1./(1./tau - 1./tau_aug -
                      2 * J0 * (nxc + Ndop) /
                      (const.e*W*ni**2)
                      )

        tau_SRH = np.mean(tau_SRH)

        tau_cor = 1./ni**2/(1./tau - 1./tau_aug - 1./tau_SRH)
        J0 = _J0_KaneSwanson(nxc, tau_cor, W, 1)
    return J0


def _J0_Kimmerle(nxc, tau, W, ni, tau_aug):
    tau_cor = 1./ni**2/(1./tau - 1./tau_aug)
    return _J0_KaneSwanson(nxc, tau_cor, W, 1)


def _J0_King(nxc, tau, W, ni, tau_aug):
    tau_cor = 1./(1./tau - 1./tau_aug)
    return _J0_KaneSwanson(nxc, tau_cor, W, ni)


def _J0_KaneSwanson(nxc, tau, W, ni):
    slope, inter = np.polyfit(nxc, 1./tau, 1)

    return const.e*W*ni**2/2*slope
