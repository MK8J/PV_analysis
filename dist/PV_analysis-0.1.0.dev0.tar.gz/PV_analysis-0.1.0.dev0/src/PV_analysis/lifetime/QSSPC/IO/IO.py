
import sys
import numpy as np
import openpyxl as pyxl

from PV_analysis.lifetime.core import lifetime as LTC

if sys.platform == "win32":
    try:
        from win32com.client import Dispatch
    except:
        pass


def Sinton2014_Settings(File):
    # This grabs the calibration constants for the coil and reference
    # This outputs them as a dictionary
    xlBook = xlApp.Workbooks.Open(File)

    # make Excel visible (1 is True, 0 is False)
    xlApp.Visible = 0

    # makes a reference to the RawData page
    xlSheet = xlBook.Sheets('Settings')

    Ref = float(xlSheet.Range('C5').Value)
    A = float(xlSheet.Range('C6').Value)
    B = float(xlSheet.Range('C7').Value)
    C = float(xlSheet.Range('C8').Value)
    Air = float(xlSheet.Range('C10').Value)

    xlBook.Close(SaveChanges=0)
    xlApp.Application.Quit()
    Dic = locals()
    for i in ['xlApp', 'xlBook', 'working_dir', 'xlSheet', 'File_path']:
        del Dic[i]

    return Dic


def Sinton2014_set_UserData(File_path, settings_dic):
    # This grabs the user entered data about the sample
    # This outputs them as a dictionary
    xlApp = Dispatch("Excel.Application")

    xlBook = xlApp.Workbooks.Open(File_path)

    # make Excel visible (1 is True, 0 is False)
    xlApp.Visible = 0

    # makes a reference to the RawData page
    xlSheet = xlBook.Sheets('User')

    # Grabbing the data and assigning it a nae
    xlSheet.Range('A6').Value = settings_dic['WaferName']
    xlSheet.Range('B6').Value = settings_dic['Thickness']
    print(settings_dic['Resisitivity'], settings_dic)
    xlSheet.Range('C6').Value = settings_dic['Resisitivity']
    xlSheet.Range('D6').Value = settings_dic['SampleType']
    xlSheet.Range('H6').Value = settings_dic['AnalysisMode']
    xlSheet.Range('E6').Value = settings_dic['OpticalConstant']

    xlBook.Close(SaveChanges=1)
    xlApp.Application.Quit()
    pass


def _dispatch_sinton2014_extractsserdata(File_path):
    # This grabs the user entered data about the sample
    # This outputs them as a dictionary
    xlApp = Dispatch("Excel.Application")
    # Set the Excel file name, working directory and path
    # This is encase you don't want to use the directory you are in

    xlBook = xlApp.Workbooks.Open(File_path)

    # make Excel visible (1 is True, 0 is False)
    xlApp.Visible = 0

    # makes a reference to the RawData page
    xlSheet = xlBook.Sheets('User')

    # Grabbing the data and assigning it a nae
    WaferName = xlSheet.Range('A6').Value.encode('utf8')
    Thickness = float(xlSheet.Range('B6').Value)
    Resisitivity = float(xlSheet.Range('C6').Value)
    Doping = float(xlSheet.Range('J9').Value)
    SampleType = xlSheet.Range('D6').Value.encode('utf8')
    AnalysisMode = xlSheet.Range('H6').Value.encode('utf8')
    OpticalConstant = float(xlSheet.Range('E6').Value)

    # makes a reference to the RawData page
    xlSheet = xlBook.Sheets('Settings')
    A = float(xlSheet.Range('C6').Value)
    B = float(xlSheet.Range('C7').Value)
    C = float(xlSheet.Range('C8').Value)

    RefCell = float(xlSheet.Range('C5').Value)

    xlBook.Close(SaveChanges=0)
    xlApp.Application.Quit()
    # Getting all those names into a dictionary
    Dic = locals()
    # Removing the names i don't want in the dictionary

    for i in ['xlApp', 'xlBook', 'File_path', 'xlSheet']:
        del Dic[i]

    return Dic


def _dispatch_Sinton2014_ExtractRawData_noplongerused(File_path):
    # import the Dispatch library, get a reference to an Excel instance
    xlApp = Dispatch("Excel.Application")
    # Set the Excel file name, working directory and path
    # This is encase you don't want to use the directory you are in

    # opens the excel book
    xlBook = xlApp.Workbooks.Open(File_path)

    # make Excel visible (1 is True, 0 is False)
    xlApp.Visible = 0

    xlSheet = xlBook.Sheets('Calc')
    Values = np.asarray(xlSheet.Range("A9:I133").Value, dtype=np.float64)

    headers = tuple([[j.encode('utf8') for j in i]
                     for i in xlSheet.Range('A8:I8').Value][0])

    Values2 = np.asarray(xlSheet.Range("O9:P133").Value, dtype=np.float64)
    headers2 = tuple([[j.encode('utf8') for j in i]
                      for i in xlSheet.Range('O8:P8').Value][0])

    # makes a reference to the RawData page
    # xlSheet = xlBook.Sheets('RawData')

    # Get the values from the page
    # Values = np.asarray(xlSheet.Range("A2:G126").Value)
    # headers = tuple([[j.encode('utf8') for j in i]
    #                  for i in xlSheet.Range('A1:G1').Value][0])

    xlBook.Close(SaveChanges=0)
    xlApp.Application.Quit()

    Values = np.hstack((Values, Values2))
    headers += headers2

    Out = Values.view(dtype=zip(headers, ['float64'] * len(headers))).copy()

    # Too see it working

    return Out


def extract_measurement_data(File_path, Plot=False):
    '''
    This grabs the calculated data from sinton
    Extracts columns A-G of the raw data page.
    Can't extract columns H-I as it is not complete data and this would take
    some more work
    This outputs the data as a structured array, with the names as the column
    '''

    wb = pyxl.load_workbook(File_path, read_only=True, data_only=True)
    # the command page was only added in the later versions
    if 'Command' in wb.get_sheet_names():
        data = _openpyxl_Sinton2014_ExtractRawDatadata(wb)
    else:
        try:
            data = _openpyxl_Sinton2014_ExtractRawDatadata(wb)
        except:
            print('Can''t load this file yet')

    # remove all the nan values from the data
    data = data[~np.isnan(data['Tau (sec)'])]

    return data


def extract_info(File_path):
    '''
    This grabs the calculated data from sinton
    Extracts columns A-G of the raw data page.
    Can't extract columns H-I as it is not complete data and this would take
    some more work
    This outputs the data as a structured array, with the names as the column
    '''

    wb = pyxl.load_workbook(File_path, read_only=True, data_only=True)
    # the command page was only added in the later versions
    if 'Command' in wb.get_sheet_names():
        settings = _openpylx_sinton2014_extractsserdata(wb)
    else:
        try:
            settings = _openpylx_sinton2014_extractsserdata(wb)
        except:
            print('Can''t load this file yet')

    return settings


def set_info(File_path, **kwargs):
    '''
    This grabs the calculated data from sinton
    Extracts columns A-G of the raw data page.
    Can't extract columns H-I as it is not complete data and this would take
    some more work
    This outputs the data as a structured array, with the names as the column
    '''

    wb = pyxl.load_workbook(File_path, keep_vba=True)
    # the command page was only added in the later versions
    if 'Command' in wb.get_sheet_names():
        settings = _openpylx_sinton2014_setuserdata(wb, kwargs)
    else:
        try:
            _openpylx_sinton2014_extractsserdata(wb)
        except:
            print('Can\'t access this file type')

    wb.save(File_path.replace('.xlsm', '1.xlsm'))


def _openpyxl_Sinton2014_ExtractRawDatadata(wb):
    '''
        reads the raw data a sinton WCT-120 spreadsheet form the
        provided instance of the openpylx workbook.
    '''

    # make sure the sheet is in the book
    assert 'Calc' in wb.get_sheet_names()

    # get the worksheet
    ws = wb.get_sheet_by_name('Calc')

    # get first section of data
    values1 = np.array([[i.value for i in j] for j in ws['A9':'I133']],
                       dtype=np.float64)
    headers1 = tuple(
        [[j.value for j in i] for i in ws['A8':'I8']][0])

    # get second section of data
    values2 = np.array([[i.value for i in j] for j in ws['O9':'Z133']],
                       dtype=np.float64)
    headers2 = tuple(
        [[j.value for j in i] for i in ws['O8':'Z8']][0])

    # form into one array with names
    values = np.hstack((values1, values2))
    headers = headers1 + headers2

    Out = values.view(dtype=list(
        zip(headers, ["float64"] * len(headers)))).copy()

    return Out


def _openpylx_sinton2014_setuserdata(wb, dic):

    # make sure the sheet is in the book
    # get the worksheet
    assert 'User' in wb.get_sheet_names()
    assert 'Settings' in wb.get_sheet_names()

    ws_user = wb.get_sheet_by_name('User')
    ws_settings = wb.get_sheet_by_name('Settings')

    # Grabbing the data and assigning it a nae
    print(dic)

    user_dic = {
        'wafer_name': 'A6',
        'thickness': 'B6',
        'resisitivity': 'C6',
        'm_resisitivity': 'C9',
        'doping': 'J9',
        'sample_type': 'D6',
        'analysis_mode': 'H6',
        'optical_constant': 'E6',
        'MCD': 'F6',
        'tau@MCD': 'A9',
        'Voc@1sun': 'K9',
        'J0': 'D9',
        'bulk_tau': 'E9',
    }
    user_set_dic = {
        'A': 'C6',
        'B': 'C7',
        'C': 'C8',
        'RefCell': 'C5',
    }

    for name in dic.keys():
        print(name)
        if name in user_dic.keys():
            print('here')
            ws_user[user_dic[name]] = dic[name]
            print(ws_user[user_dic[name]].value)
        else:
            print('or here')
            print(name, ' not recognoised')
    # makes a reference to the RawData page

    # save the work book
    pass


def _openpylx_sinton2014_extractsserdata(wb):

    # make sure the sheet is in the book
    # get the worksheet
    assert 'User' in wb.get_sheet_names()
    assert 'Settings' in wb.get_sheet_names()

    ws = wb.get_sheet_by_name('User')

    # Grabbing the data and assigning it a nae

    user_set = {
        'wafer_name': ws['A6'].value.encode('utf8'),
        'thickness': float(ws['B6'].value),
        'resisitivity': float(ws['C6'].value),
        'm_resisitivity': float(ws['C9'].value),
        'doping': float(ws['J9'].value),
        'sample_type': ws['D6'].value.encode('utf8'),
        'analysis_mode': ws['H6'].value.encode('utf8'),
        'optical_constant': float(ws['E6'].value),
        'MCD': float(ws['F6'].value),
        'tau@MCD': float(ws['A9'].value),
        'Voc@1sun': float(ws['K9'].value),
        'J0': float(ws['D9'].value),
        'bulk_tau': float(ws['E9'].value),
    }

    # makes a reference to the RawData page

    ws = wb.get_sheet_by_name('Settings')

    sys_set = {
        'A': float(ws['C6'].value),
        'B': float(ws['C7'].value),
        'C': float(ws['C8'].value),
        'RefCell': float(ws['C5'].value),
    }

    # make one dic
    user_set.update(sys_set)

    return user_set


def load_lifetime(file_path):
    '''
    Loads a Sinton excel and passes it into a lifetime class, with the
    attributes automatically filled. You still need to check that the Sinton
    excel values were correctly choosen.
    '''

    # define the lifetime class
    ltc = LTC()
    # get the measurement data
    data = extract_measurement_data(file_path)
    inf = extract_info(file_path)

    # pass to the lifetime class
    ltc.tau = data['Tau (sec)']
    ltc.nxc = data['Minority Carrier Density']
    ltc.gen = data['Generation (pairs/s)']

    if inf['sample_type'] == b'p-type':
        inf['dopant'] = 'boron'
    elif inf['sample_type'] == b'n-type':
        inf['dopant'] = 'phosphorus'

    # Pasa a dic to update atttrs, but turn off warnings
    # for non attributes first
    ltc._warnings = False
    ltc.attrs = inf
    # turns the warnings back on
    ltc._warnings = True

    return ltc
