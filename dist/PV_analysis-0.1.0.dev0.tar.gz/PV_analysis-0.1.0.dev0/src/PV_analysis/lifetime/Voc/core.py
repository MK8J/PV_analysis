

import numpy as np
import scipy.constants as const
from PV_analysis.lifetime.core import lifetime as LTC


def Voc_2_deltan(V, doping, ni, temp):
    '''
    caculates the excess carrier density from a voltage
    inputs:
        V (array like):
            voltage in Volts
        Nd: (float in cm^-3)
            dopipng in
        ni: (float in (cm^-3))
            intrinsic carrier density
        temp: (float in K)
            Temperature
    outputs:
        nxc: The number of excess carriers.
    '''
    Vt = const.k * temp / const.e

    return (np.sqrt(doping**2. + 4. * ni**2 * (np.exp(V / Vt) - 1.)) - doping) / 2.


class lifetime_Voc(LTC):

    # raw measurements
    V = None
    gen_V = None

    Fs = None  # this is the generation calibration value

    def cal_lifetime(self, analysis=None):
        # get dn
        self.nxc = Voc_2_deltan(self.V, self.doping, self.ni, self.temp)
        # get gen
        self.gen = self.gen_V * self.Fs / self.thickness
        # then do lifetime
        self._cal_lifetime(analysis=None)
