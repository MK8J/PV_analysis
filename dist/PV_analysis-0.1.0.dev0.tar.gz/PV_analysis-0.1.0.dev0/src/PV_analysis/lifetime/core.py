

import numpy as np
import matplotlib.pylab as plt
import sys
import os
from semiconductor.recombination.intrinsic import Intrinsic as IntTau
from semiconductor.material.ni import IntrinsicCarrierDensity


def tau_ext_from_tau_eff(self, tau_eff, min_car_den, Na, Nd, **kwargs):
    '''
    Determines the extrinsic carrier lifetime,
    by subtraction of the intrinsic carrier lifetime

    inputs:
        tau_eff,
            the effective carrier lifetime  in s
        min_car_den:
            the minorty carrier density in cm^-3
        Na:
            number of acceptor dopants (p-type)
        Nd:
            number of donor dopants (n-type)
        **kwargs
            any special parameters for the intrinsic lifetime caculation
    '''

    tau = IntTau(material='Si', **kwargs)
    return 1. / (1. / tau_eff - 1. / tau.tau(min_car_den, Na, Nd))


def murphy_plot(nxc, tau_ext, ax, label=None):
    '''
    plots lifetime data the Murphy way (10.1063/1.4725475)
    This is particularly useful for when looking for
    SRH defects
    '''

    ax.plot(nxc, tau_ext, ':',
            label=None)

    ax.legend(loc=0)
    ax.set_xlabel('n/p')
    ax.set_ylabel('$\tau_{eff}$ (s)')


def caltau_generalised(nxc, gen, time):
    '''
    caculates the lifetime with the generatlised method
    inputs:
        nxc: (array like (cm^-3))
            number of excess carrier density
        gen: (array like (cm^-3))
            number of photons. Required to the be same shape as nxc
        time: (array like (s))
            the time for which the excess carrier density and generation is
            reported
    output:
        tau: (array like (s))
            the effective lifetime in seconds
    '''

    dndt = np.gradient(nxc, time[2] - time[1])

    return nxc / (gen - dndt)


def caltau_steadystate(nxc, gen, *args):
    '''
    caculates the lifetime with the generatlised method
    inputs:
        nxc: (array like (cm^-3))
            number of excess carrier density
        gen: (array like (cm^-3))
            number of photons. Required to the be same shape as nxc
    output:
        tau: (array like (s))
            the effective lifetime in secondsds
    '''

    return nxc / (gen)


def caltau_transient(nxc, time, *args):
    '''
    caculates the lifetime using the assuming a transient
    inputs:
        nxc: (array like (cm^-3))
            number of excess carrier density
        time: (array like (s))
            the time for which the excess carrier density and generation is
            reported
    output:
        tau: (array like (s))
            the effective lifetime in seconds
    '''

    dndt = np.gradient(nxc, time)

    return nxc / (dndt)


class lifetime():

    # sample properties
    doping = None
    thickness = None
    dopant = None

    # measured values
    time = None
    gen = None
    nxc = None

    # caculated value
    tau = None

    file_name = None
    wafer_name = None
    temp = 300
    ni_author = None
    analysis = 'generalised'

    _analsis_methods = {
        'generalised': caltau_generalised,
        'transient': caltau_steadystate,
        'steadystate': caltau_transient,
    }

    _warnings = True

    def __init__(self, **kwargs):
        self.attr = kwargs
        pass

    def _cal_lifetime(self, analysis=None):
        self.analysis = analysis or self.analysis
        self.tau = self._analsis_methods[self.analysis](
            nxc=self.nxc, gen=self.gen, time=self.time)

    @property
    def iVoc(self):
        '''
        returns the open circuit voltage of the device
        '''
        return const.k * temp / const.e * np.log(
            self.nxc * (self.nxc + self.doping) / self.ni**2)

    @property
    def ni(self):
        return IntrinsicCarrierDensity(
            material='Si', temp=self.temp, author=self.ni_author
        ).update()

    @property
    def attrs(self):
        return {
            'doping': self.doping,
            'thickness': self.thickness,
            'dopant': self.dopant,
            'tau': self.tau,
            'nxc': self.nxc,
        }

    @attrs.setter
    def attrs(self, kwargs):
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            elif self._warnings:
                print('Attribute {0} not found'.format(key))

    def crop_nxc(self, min_nxc, max_nxc):
        '''
        Crops the data to a provided carrier density
        '''

        index = self.nxc > min_nxc
        index *= self.nxc < max_nxc

        self.nxc = self.nxc[index]
        self.tau = self.tau[index]
        self.gen = self.gen[index]
# class fit_sintons(CommonLifetimeFunctions):
#
#
#     def __init__(self, fnames, num_SRH, Jo):
#         '''
#                 fnames: (str or list)
#                         The file path to a Sinton file or a list
#                         of file paths all to be fitted at the same time
#                 num_SRH: (int)
#                         The number of SRH defects to be fitted
#                 Jo: (bool)
#                         If Jo should be fitted
#                 sinton_version: (str ['b42014','af2014'])
#                         A string that tells the if the Sinton file is older that 2014
#         '''
#
#         self.fnames = fnames
#         self.num_SRH = num_SRH
#         self.Jo = Jo
#
#         self._check_inputs()
#         self._input()
#
#     def _check_inputs(self):
#         # if fnames is string make list
#         if isinstance(self.fnames, str):
#             self.fnames = [self.fnames]
#
#         # make sure files exist
#         for fname in self.fnames[:]:
#             if not os.path.isfile(fname):
#                 print ('File path does not exist: ', fname,)
#                 cont = raw_input('File removed from list and continue?\n')
#                 if cont == 'n':
#                     sys.exit("Program stopped by user")
#                 elif cont == 'y':
#                     self.fnames.remove(fname)
#
#         assert isinstance(self.num_SRH, int)
#         assert isinstance(self.Jo, bool)
#
#     def _input(self):
#
#         self.m_data = []
#         self.input_data = []
#         for fname in self.fnames[:]:
#             self.m_data.append(WCT.extract_raw_data(fname))
#             self.input_data.append(WCT.extract_usr_data(fname))
#
#     def _plot(self):
#         fig, ax  = plt.subplots()
#         for data, inf in zip(self.m_data, self.input_data):
#             print (inf['thickness'], inf['optical_constant'], inf['doping'], inf['resisitivity'], inf['m_resisitivity'])
#
#             ax.plot(data['Minority Carrier Density'], data['Tau (sec)'], label=inf['wafer_name'])
#             # ax.plot(data['Apparent CD'][2:-2], data['Tau (sec)'][2:-2], label=inf['wafer_name'])
#
#
#         ax.legend(loc=0)
#         ax.loglog()
#         ax.set_xlabel('Excess carriers')
#         ax.set_ylabel('Lifetime (s)')
#
#         plt.show()
#
#     def plot_murfy(self):
#         fig, ax  = plt.subplots(1)
#         for data, inf in zip(self.m_data, self.input_data):
#             self.nxc = data['Minority Carrier Density']
#             self.tau_ext = self.tau_ext_from_tau_eff(data['Tau (sec)'], data['Minority Carrier Density'], 0, inf['doping'])
#             self._plot_murfy(ax)
