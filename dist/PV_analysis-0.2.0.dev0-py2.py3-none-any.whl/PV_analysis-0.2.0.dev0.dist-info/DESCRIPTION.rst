# PV_analysis

This is just a place for some common analysis that needs to be done in photovoltaics.
Nothing special. 

Currently this is quite limited, with an outline of what can be done being provided below. 

## Current voltage analysis

  1. Simple curve fitting, using the circuit equivalent model, of light IV, dark IV, and Suns Voc.
  2. Extraction of parameters such as Jsc, Voc, Pmax, and other from both the raw data and simulated data.
  3. Caculationg of local idealiy, and power verus voltage.


## Minoirty carrier lifetime analysis

Currently very basic:
* Can determine J0e from a meaurement near high injection. 


## PL image analysis

Currently very basic


