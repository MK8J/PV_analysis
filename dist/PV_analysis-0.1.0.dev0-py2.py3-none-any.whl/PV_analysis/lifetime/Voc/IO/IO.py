
import sys
import numpy as np
import openpyxl as pyxl

from PV_analysis.lifetime.core import lifetime as LTC


def load_data(file_path):
    '''
    Loads a tab spaced text file and
    returns a lifetime class
    '''

    # define the lifetime class
    ltc = LTC()
    # get the measurement data
    data = extract_measurement_data(file_path)
    inf = extract_info(file_path)

    # pass to the lifetime class
    ltc.nxc = data['V']
    ltc.gen = data['Gen']

    if inf['sample_type'] == b'p-type':
        inf['dopant'] = 'boron'
    elif inf['sample_type'] == b'n-type':
        inf['dopant'] = 'phosphorus'

    # Pasa a dic to update atttrs, but turn off warnings
    # for non attributes first
    ltc._warnings = False
    ltc.attrs = inf
    # turns the warnings back on
    ltc._warnings = True

    return ltc
