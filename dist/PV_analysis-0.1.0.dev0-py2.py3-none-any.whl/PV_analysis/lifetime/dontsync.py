# class fit_sintons(CommonLifetimeFunctions):
#
#
#     def __init__(self, fnames, num_SRH, Jo):
#         '''
#                 fnames: (str or list)
#                         The file path to a Sinton file or a list
#                         of file paths all to be fitted at the same time
#                 num_SRH: (int)
#                         The number of SRH defects to be fitted
#                 Jo: (bool)
#                         If Jo should be fitted
#                 sinton_version: (str ['b42014','af2014'])
#                         A string that tells the if the Sinton file is older that 2014
#         '''
#
#         self.fnames = fnames
#         self.num_SRH = num_SRH
#         self.Jo = Jo
#
#         self._check_inputs()
#         self._input()
#
#     def _check_inputs(self):
#         # if fnames is string make list
#         if isinstance(self.fnames, str):
#             self.fnames = [self.fnames]
#
#         # make sure files exist
#         for fname in self.fnames[:]:
#             if not os.path.isfile(fname):
#                 print ('File path does not exist: ', fname,)
#                 cont = raw_input('File removed from list and continue?\n')
#                 if cont == 'n':
#                     sys.exit("Program stopped by user")
#                 elif cont == 'y':
#                     self.fnames.remove(fname)
#
#         assert isinstance(self.num_SRH, int)
#         assert isinstance(self.Jo, bool)
#
#     def _input(self):
#
#         self.m_data = []
#         self.input_data = []
#         for fname in self.fnames[:]:
#             self.m_data.append(WCT.extract_raw_data(fname))
#             self.input_data.append(WCT.extract_usr_data(fname))
#
#     def _plot(self):
#         fig, ax  = plt.subplots()
#         for data, inf in zip(self.m_data, self.input_data):
#             print (inf['thickness'], inf['optical_constant'], inf['doping'], inf['resisitivity'], inf['m_resisitivity'])
#
#             ax.plot(data['Minority Carrier Density'], data['Tau (sec)'], label=inf['wafer_name'])
#             # ax.plot(data['Apparent CD'][2:-2], data['Tau (sec)'][2:-2], label=inf['wafer_name'])
#
#
#         ax.legend(loc=0)
#         ax.loglog()
#         ax.set_xlabel('Excess carriers')
#         ax.set_ylabel('Lifetime (s)')
#
#         plt.show()
#
#     def plot_murfy(self):
#         fig, ax  = plt.subplots(1)
#         for data, inf in zip(self.m_data, self.input_data):
#             self.nxc = data['Minority Carrier Density']
#             self.tau_ext = self.tau_ext_from_tau_eff(data['Tau (sec)'], data['Minority Carrier Density'], 0, inf['doping'])
#             self._plot_murfy(ax)
