
import numpy as np


def Binning(data, BinAmount):

    if len(data.shape) != 1:
        data2 = np.zeros((data.shape[0] // BinAmount, data.shape[1]))
    else:
        data2 = np.zeros((data.shape[0] // BinAmount))

    for i in range(data.shape[0] // BinAmount):
        data2[i] = np.mean(data[i * BinAmount:(i + 1) * BinAmount], axis=0)

    return data2


def Binning_Named(data, BinAmount):

    if len(data.dtype.names) != 1:
        data2 = np.copy(data)[::BinAmount]

    for i in data.dtype.names:
        for j in range(data.shape[0] // BinAmount):
            data2[i][j] = np.mean(
                data[i][j * BinAmount:(j + 1) * BinAmount], axis=0)

    return data2


class sample():

    name = None
    sample_id = None
    _doping = None
    dopant_type = None  # takes either 'n-type' or 'p-type'
    thickness = None
    absorptance = 1
    _Na = None
    _Nd = None
    temp = 300  # as most measurements are done at room temperature

    def attrs(self, dic):
        '''
        sets the values in a dictionary
        '''
        assert type(dic) == dict
        for key, val in dic.items():
            if hasattr(self, key):
                setattr(self, key, val)

    @property
    def doping(self):
        '''
        returns the defined doping or tries to caculate it from the
        number of donor and acceptors. To use the caculated value,
        just set the doping to None.
        '''
        try:
            doping = abs(self._Na - self._Nd)
        except:
            doping = None
        doping = self._doping or None
        return doping

    @doping.setter
    def doping(self, value):
        '''
        returns the defined doping or tries to caculate it from the
        number of donor and acceptors. To use the caculated value,
        just set the doping to None.
        '''
        self._doping = value

    @property
    def Na(self):
        Na = None
        if self.dopant_type == 'p-type':
            Na = self._doping
        elif self.dopant_type == 'n-type':
            Na = 0
        else:
            print('Na dopant_type not defined')

        return self._Na or Na

    @Na.setter
    def Na(self, value):
        self._Na = value

    @property
    def Nd(self):
        Nd = None
        if self.dopant_type == 'n-type':
            Nd = self._doping
        elif self.dopant_type == 'p-type':
            Nd = 0
        else:
            print('ND dopant_type not defined')

        return self._Nd or Nd

    @Nd.setter
    def Nd(self, value):
        self._Nd = value
