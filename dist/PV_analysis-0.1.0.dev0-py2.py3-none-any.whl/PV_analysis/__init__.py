from __future__ import division, absolute_import, print_function

from . import common
from . import lifetime
__version__ = "0.1.0.dev0"

__title__ = "PV_analysis"
__description__ = """A place to store helpy functions to analyise measurements common in photovoltaics"""

__author__ = "Mattias Juhl"
__email__ = "mattias.juhl@gmail.com"

__license__ = "MIT"
__copyright__ = "Copyright (c) 2016 Mattias Juhl"
