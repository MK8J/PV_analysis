

import numpy 
import scipy 


def Laplacian(PL_image, calibration, sheet_res):
    pass