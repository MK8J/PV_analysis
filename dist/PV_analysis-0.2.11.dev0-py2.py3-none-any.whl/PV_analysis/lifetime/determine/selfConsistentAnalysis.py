
import numpy as np
import sys
from scipy.optimize import minimize, newton


def selfConsistentAnalysis(time, val_rel, gen=None, nxc=None, c=1):
    '''
    Performs a self consistent analysis on lifetime dataself.
    Either a known generation rate of excess carrier density must be provided.

    inputs:
        time: (array, s)
            The time using equal time steps
        val_rel: (array like, cm^-3)
            The value that is to be determined self consistently. This can be either a generation rate or an excess carrier density. The provided value should be linear with the value to be determined.
        gen: (arraly like, optional, cm^-3)
            The generation rate
        nxc: (arraly like, optional, cm^-3)
            The generation rate
        c: (float, optional, default=1)
            A guess at the correction factor

        return
    '''

    if gen is None:
        _gen = val_rel * c
    else:
        _gen = gen

    if nxc is None:
        _nxc = val_rel * c
    else:
        _nxc = nxc

    def _minimise(c, _nxc, _gen):
        '''
        This does noting.
        '''
        c = abs(c)
        if gen is None:
            _gen = val_rel * c
        if nxc is None:
            _nxc = val_rel * c

        _dndt = np.gradient(_nxc, time[1] - time[0])
        _tau = _nxc / (_gen - _dndt)
        # print(c, np.trapz(_tau[:index], _nxc[:index]) -
        # np.trapz(_tau[index:], _nxc[index:]))
        return abs(np.trapz(_tau[:index], _nxc[:index]) - np.trapz(_tau[index:], _nxc[index:]))

    def _root(c, _nxc, _gen):
        '''
        Find the best "c"
        '''
        c = c

        if gen is None:
            _gen = val_rel * c
        if nxc is None:
            _nxc = val_rel * c

        _dndt = np.gradient(_nxc, time[1] - time[0])
        _tau = _nxc / (_gen - _dndt)

        _index = _nxc > np.amax(_nxc) / 10
        _index *= _nxc > 0
        _index *= _tau > 0

        _indexmax = _nxc[_index].argmax()
        _tau = _tau[_index]

        # the integral over the area should be zero.
        # we normalise this to the average area to make it a percent like
        val = np.trapz(_tau, _nxc[_index]) / abs(
            np.trapz(_tau[:_indexmax + 1], _nxc[_index][:_indexmax + 1]
                     ) - np.trapz(
                _tau[_indexmax:], _nxc[_index][_indexmax:])
        )

        # plt.figure('newton')
        # plt.plot(_nxc[_index][:_indexmax + 1], _tau[:_indexmax + 1])
        # plt.plot(_nxc[_index][_indexmax:], _tau[_indexmax:], '.')
        # plt.show()

        return val

    c = newton(_root,  c, args=(_nxc, _gen))
    print('the value is', c)
    if gen is None:
        val_rel = val_rel * abs(c)
        _gen = val_rel

    if nxc is None:
        val_rel = val_rel * abs(c)
        _nxc = val_rel

    _dndt = np.gradient(_nxc, time[1] - time[0])
    tau = _nxc / (_gen - _dndt)

    return tau, val_rel


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    t = np.linspace(0, 0.001, 1000)
    f = 1000 * 2 * np.pi
    w = 0.018
    A = 1e17 / w
    gen = A * (np.cos(t * f + np.pi) + 1)
    tau = 1e-6
    _tau = tau

    nxc = A * f * tau**2 * (
        -np.sin(t * f) + f * tau) / (
        f**2 * tau**2 + 1
    ) + A * tau * (-np.cos(t * f) + 1) / (
        f**2 * tau**2 + 1
    )

    dndt = np.gradient(nxc, t[1] - t[0])

    plt.figure('delay')
    plt.plot(t, nxc / np.amax(nxc))
    plt.plot(t, gen / np.amax(gen), 'r--')
    # plt.ylim(0.999, 1)
    # plt.xlim(0.495 * t[-1], 0.505 * t[-1])

    # plt.semilogy(
    plt.figure()
    plt.plot(t, gen)
    plt.plot(t, abs(dndt))
    plt.semilogy()

    plt.figure()
    plt.plot(nxc, nxc / (gen - dndt))
    plt.semilogx()
    # plt.show()

    tau, _nxc = selfConsistentAnalysis(t, nxc * 1e3, gen=gen, nxc=None, c=1e-2)

    plt.plot(_nxc, tau, 'r--')
    plt.plot(nxc, nxc / gen)

    # plt.ylim()
    plt.ylim(bottom=0.8 * _tau, top=1.2 * _tau)
    plt.show()
    #
    # data = np.genfromtxt(r'/Users/user/OneDrive - UNSW/UNSW/PhD/backup/Measurements/PHD/QSSPL/EQE Work/EQE_Samples/Diffused SiNx/1_808-High_1e4_1e8_Raw Data.dat',
    #                      dtype=float, comments='#', delimiter='\t', names=['time', 'pc', 'ref', 'pl'])
    # #
    # plt.figure()
    # plt.plot(data['time'],
    #          data['ref'] / np.amax(data['ref']))
    # plt.plot(data['time'], data['pl'] / np.amax(data['pl']))
    # #
    # data['ref'] *= 1e16 / 0.018
    # plt.figure()
    # tau, _nxc = selfConsistentAnalysis(
    #     t, data['pl'], gen=data['ref'], nxc=None, c=1e16)
    #
    # plt.plot(_nxc, _nxc / data['ref'], '.')
    #
    # plt.plot(_nxc, tau, 'r--')
    # plt.plot(_nxc, -tau, 'b--')
    #
    # plt.loglog()
    #
    # plt.figure('gen')
    # plt.plot(data['time'], data['ref'])
    # plt.plot(data['time'], abs(np.gradient(_nxc, data['time'][1])))
    #
    # plt.semilogy()
    #
    # #
    # plt.ylim(bottom=1e14)
    # # plt.xlim(0.3, 0.4)
    #
    # plt.show()
