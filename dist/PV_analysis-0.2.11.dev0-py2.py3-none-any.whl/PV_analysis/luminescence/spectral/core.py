
from PV_analysis.common import IO
import numbers


class spectral():

    # sample properties
    sample = {
        'name': None,
        'doping': None,
        'thickness': None,
        'dopant': None,
        'optical_c': None,
        'temp': None,
        'V_t': None,
        'I_t': None,
        'area': None,
    }

    # measured values
    raw_wavelength = None
    raw_bg = None
    raw_lum = None
    wavelength = None
    lum = None

    # caculated value
    tau = None

    file_name = None

    _warnings = True
    _type = ''  # a saving extension

    def __init__(self, **kwargs):
        self.attr = kwargs
        pass

    def correct_bg(self):
        '''
        background corrects the data
        '''
        try:
            if self.raw_lum is None:
                if self.lum is not None:
                    self.raw_lum = self.lum
                else:
                    print('No data loaded')
                    raise

            if self.raw_bg is None:
                print('No background data loaded')
                raise

            if self.raw_lum.shape[0] == self.raw_bg.shaoe[0]:
                self.lum = self.raw_lum - self.raw_bg
            else:
                print('Background data and measured data are different shapes')

                raise
        except:
            pass

    def crop_wavelength(self, min_wl, max_wl):
        '''
        Crops the data to a provided wavelength range
        '''

        index = self.raw_wavelength > min_nxc
        index *= self.raw_wavelength < max_nxc

        self.wavelength = self.raw_wavelength[index]
        self.lum = self.lum[index]

    def save(self):
        '''
        does nothing, but it should do
        '''
        pass
