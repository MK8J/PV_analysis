
import numpy as np
from PV_analysis.luminescence.spectral.core import spectral as SPL
import scipy.constants as const


def load_data(file_path, file_format='raw'):
    '''
    Loads a tab spaced text file and
    returns a lifetime class
    '''

    file_ext_dic = {
        'raw': '_load_raw',
        'LG25': '_load_LG25'
    }

    # define the spectral class
    spl = SPL()

    # get the measurement data
    method - file_ext_dic[file_format]
    data = file_ext_dic[method](file_path)
    try:
        inf = extract_info(file_path.replace('.dat', '.inf'))
    except:
        print('inf file not found')

    # pass to the lifetime class
    spl.raw_wavelength = data['wavelength']
    spl.raw_lum = data['Voc']
    spl.raw_bg = data['background']

    # Pasa a dic to update atttrs, but turn off warnings
    # for non attributes first
    spl._warnings = False
    spl.attrs = inf
    # turns the warnings back on
    spl._warnings = True

    return ltc


def _load_raw(file_path):
    data = np.genfromtxt(file_path, delimiter='\t', names=True)
    return data


class lg25():
    r = None
    theta = None
    x = None
    y = None
    wl = None

    def change_theta(self, delta_theta):
        x = self.r * np.cos(self.theta + delta_theta)
        y = self.r * np.sin(self.theta + delta_theta)
        # self.theta = theta
        return x, y

    def EQE(self, val):
        a = 1

        def BB(emn_wavelegnth, temp=300):
            '''
            wl in nm
            '''
            # wavelength to meters
            emn_wavelegnth = emn_wavelegnth * 1e-9

            return const.c / emn_wavelegnth**4 * 1. / (
                np.exp(const.h * const.c / emn_wavelegnth / const.k /
                       temp) - 1.)

        return 1. / BB(self.wl) * val


def load_LG25(file_path):

    data = np.genfromtxt(file_path, skip_footer=13, skip_header=1)

    _lg25 = lg25()

    val = int((data.shape[1] - 1) / 2)
    _lg25.wl = data[:, 0]
    _lg25._x = data[:, 1:val + 1]
    _lg25.x = np.nanmean(_lg25._x, axis=1)
    _lg25._y = data[:, val + 1:]
    _lg25.y = np.nanmean(_lg25._y, axis=1)
    _lg25.r = np.sqrt(_lg25.x**2 + _lg25.y**2)
    _lg25.theta = np.arctan(_lg25.y / _lg25.x)
    return _lg25
