
from PV_analysis.common import IO, sample


class image():
    '''
    A class to handel PL images
    '''

    image = None
    fname = None
    # measurement settings
    exposure = None
    photonflux = None

    # electrical settings
    JL = None
    Vtm = None
    Jtm = None
    # file names
    fnames = None

    # deconvolution status
    deconvolved = None
    _warnings = False

    def __init__(self, **kwargs):

        self.sample = sample()
        self.attrs = kwargs

    @property
    def image_norm(self):
        assert self.image is not None
        assert self.exposure is not None
        return self.image / self.exposure

    @property
    def attrs(self):
        return {None}

    @attrs.setter
    def attrs(self, kwargs):
        self.other_inf = {}
        assert type(kwargs) == dict

        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            elif hasattr(self.sample, key):
                setattr(self.sample, key, value)
            else:
                if self._warnings:
                    print('Attribute {0} not found'.format(key))
                    print('Attribute set in dic other_inf')
                self.other_inf[key] = value
