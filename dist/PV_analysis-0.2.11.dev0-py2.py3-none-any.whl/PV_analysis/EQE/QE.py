

import numpy as np
import matplotlib.pylab as plt
import sys

import semiconductor.optical.opticalproperties as OP
from scipy import interpolate
from scipy import optimize
import scipy.constants as const


class IQE():

    def __init__(self):
        self.OpticalConstants = OP.TabulatedOpticalProperties(
            abs_author='Schinke_2015')

    def _wavelength2alpha(self, wavelength):

        # this go tput in because some suer were usuing scipy 0.13
        try:
            f = interpolate.interp1d(self.OpticalConstants.wavelength,
                                     self.OpticalConstants.abs_cof_bb,
                                     kind='slinear',
                                      assume_sorted=False
                                     )
        except:
                f = interpolate.interp1d(self.OpticalConstants.wavelength,
                                         self.OpticalConstants.abs_cof_bb,
                                         kind='slinear',
                                         )

        return f(wavelength)

    def _alpha2wavelength(self, alpha):

        # this go tput in because some suer were usuing scipy 0.13
        try:
            f = interpolate.interp1d(self.OpticalConstants.abs_cof_bb,
                                     self.OpticalConstants.wavelength,
                                     kind='slinear',
                                     assume_sorted=False
                                     )
        except:
            f = interpolate.interp1d(self.OpticalConstants.abs_cof_bb,
                                     self.OpticalConstants.wavelength,
                                     kind='slinear',
                                     )

        return f(alpha)

    def _check_IQE(self, IQE, check=True):
        '''
        we require IQE to between 0 and 1
        '''

        if np.amax(IQE > 1):
            IQE /= 100.

        return IQE

    def FitShortWavelength(self, wavelength, IQE):
        '''Currently doesn't do anything'''
        # plt.plot(self._wavelength2alpha(wavelength), 1. / IQE)
        pass

    def _Plot_ialpha_iIQE(self, ialpha, iIQE, ls='o', label=None):
            # print np.amax(inv_fitalpha)
        if np.amax(ialpha) < 1e-3:
            scale = 1e6 / 100
            units = 'um'
        elif np.amax(ialpha) < 1:
            scale = 1e3 / 100
            units = 'mm'

        else:
            scale = 1
            units = 'cm'

        plt.plot(ialpha * scale, iIQE, ls, label=label)

        x = np.linspace(0, np.amax(ialpha))

        plt.xlabel('Absorption depth ' + units)
        plt.ylabel('IQE$^{-1}$')

    def _fit_invIQE_invalpha(self, inv_alpha, IQE, lower_bound, upper_bound):
        '''
        Uses a linear model for the fit of inverse IQE to inverse alpha
        the lower and upper bounds are limits for which alpha should be fit

        returns the gradient and intercept

        It is to be used with other functions, such as D Lan's Or Basores
        '''
        if upper_bound < lower_bound:
            print ('Please check your alpha bounds')

        index = inv_alpha > lower_bound
        index *= inv_alpha < upper_bound

        print (lower_bound * 1e6, upper_bound * 1e6)

        inv_alpha = inv_alpha[index]
        IQE = IQE[index]

        m, b = np.polyfit(inv_alpha, 1. / IQE, 1)

        return m, b, inv_alpha, IQE

    def fit_weakabsorption(self, wavelength, IQE, upper_bound=1125, w=0.018, Plot=False):
        '''
        analysis from Lan2014.
        Fits to absorption depths > 1cm.
        There is an upper bound as parsitic absorption increase at longwavelength preventing analysis

        inputs:
            wavelength: is the wavelength
            IQE:        is the IQE
            upper_bound: is the upper bound in wavelength (defults is 1125)
            w:          (in cm)is the thickness, and used to determine the lower limit
                default is .018
            Plot:        (bool), if true will plot cropped data and fit

        returns the collection efficiency, and the parsitic absorption coefficient
        '''

        # check to make sure IQE max is 1
        IQE = self._check_IQE(IQE)

        # get alpha
        alpha = self._wavelength2alpha(wavelength)

        # set lower bound
        lower_fraction = 7
        lower_bound = (w * lower_fraction)

        # fit
        m, b, inv_fitalpha, fitIQE = self._fit_invIQE_invalpha(1. / alpha,
                                                               IQE,
                                                               lower_bound,
                                                               1. /
                                                               self._wavelength2alpha(
                                                                   upper_bound),
                                                               )

        if Plot:
            plt.plot(inv_fitalpha * 10, 1. / fitIQE, 'o')

            x = np.linspace(0, np.amax(inv_fitalpha))
            plt.plot(x * 10, m * x + b, 'r--')

            plt.xlabel('Absorption depth (mm)')
            plt.ylabel('IQE$^{-1}$')

        return m, b

    def fit_longwavelengths(self, wavelength, IQE, thickness,
                            theta=0, model='Isenberg', **kwargs):
        '''
        Fits to the long wavelengths to determine
        the bulk diffusion length and the rear surface recombination
        '''
        # IQE = self._check_IQE(IQE, True)
        IQE = self._check_IQE(IQE)
        self.thickness = thickness

        try:
            vals = getattr(
                self, 'fit_' + model)(wavelength, IQE, theta, **kwargs)
        except:
            print ('incorrect or model failed ')
            print ('fit_' + model)

        return vals

    def fit_Basore(self, wavelength, IQE, theta, Plot=False, wlbounds=[800, 950]):
        '''
        Performs the fit of Basore. doi:10.1109/PVSC.1993.347063
        this is just a linear fit in the wavelengths 800-950 to and
        extracts an effective bulk diffusion length.

            returns:
            a dictionary containing
                L_eff: the effective diffusion length (cm)
                1: A value from the fit that is meant to be 1
        '''
        index = wavelength > wlbounds[0]
        index *= wavelength < wlbounds[1]

        IQE = IQE[index]
        wavelength = wavelength[index]

        fitting_params = ['Leff', '1']

        alpha = self._wavelength2alpha(
            wavelength) / float(np.cos(np.radians(theta)))

        fit_values = np.polyfit(1. / alpha, 1. / IQE, 1)
        self.conv_matrix = 'Not implimented'

        if Plot:
            self._Plot_ialpha_iIQE(1. / alpha, 1. / IQE, 'ro')
            self._Plot_ialpha_iIQE(
                1. / alpha, np.polyval(fit_values, 1. / alpha), 'm--', label='Basore')

        return {fitting_params[i]: fit_values[i]
                for i in range(len(fitting_params))}

    def fit_Lagowski_Spiegel(self, wavelength, IQE, theta, Plot=False, wlbounds=[650, 940]):
        '''
        Performs the fit of Isenberg and Spiegel using the Lagowski_Spiegel_function
        It is fitted by default between the wavelengths of 650 and 940.

        Attempts to account for both the impact of the effective diffusion length
        and the bulk diffusion length. This is considered an improvement of the
        Basore method as it was demonstrated that a single Leff value can result in different inverse
        IQE versus wavelength. The short wavelength side is reduced as a "dead" layer is placed
        at the front of the device.

        dois: 10.1063/1.110292, 10.1109/PVSC.2000.915823

            returns:
            a dictionary containing
                L_eff: the effective diffusion length (cm)
                L: the diffusion length
                Wd: and the width of the dead layer (cm/s)
        '''
        fitting_params = ['Leff', 'L', 'Wd']

        index = wavelength > wlbounds[0]
        index *= wavelength < wlbounds[1]

        IQE = IQE[index]
        wavelength = wavelength[index]

        alpha = self._wavelength2alpha(
            wavelength) / float(np.cos(np.radians(theta)))

        p0 = (.09, 0.1, 5e-6)

        fit_values, self.conv_matrix = optimize.curve_fit(
            self.Lagowski_Spiegel_function, alpha, IQE, p0=p0)

        if Plot:
            self._Plot_ialpha_iIQE(1. / alpha, 1. / IQE)
            self._Plot_ialpha_iIQE(
                1. / alpha,
                1. / self.Lagowski_Spiegel_function(alpha, *fit_values),
                'b--',
                label='L&S')

        return {fitting_params[i]: fit_values[i]
                for i in range(len(fitting_params))}

    def Lagowski_Spiegel_function(self, alpha, Leff, L, Wd):
        '''
        Is fit function used by  two authors.
        Leff is the effective diffusion length,
        L is the actual diffusion length
        Wd is the width of the dead layer. So is no dead layer no Wd.

        This feature is currently turned off as it has not been implemented
        '''

        IQE = np.exp(-alpha * Wd) * (1. - np.power(Leff * alpha, -1.)) / \
            (1. - np.power(L * alpha, -2.))

        # this is meant to prevent impossible values
        if Leff > L or Wd < 0 or Leff < 0:
            IQE *= 2

        return IQE

    def Isenberg_function(self, alpha, L, S, emitter_width):
        # S=0
        # S = abs(S)

        D = 27.  # The diffusion constant cm^2/s
        W = self.thickness - emitter_width

        SigmaW = (S * L / D * np.cosh(W / L) + np.sinh(W / L)) / \
            (S * L / D * np.sinh(W / L) + np.cosh(W / L))

        f0 = L ** 2. / D * alpha / (1. - (L * alpha)**2.)
        fd0 = -alpha * f0
        fW = f0 * np.exp(-alpha * W)
        fdW = -alpha * fW

        IQE = D / L * (SigmaW * f0 + L * fd0) - D * (S * fW / D + fdW) / (
            S * L / D * np.sinh(W / L) + np.cosh(W / L))

        if S < 0 or L < 0 or emitter_width < 0:
            IQE *= 4

        return IQE * np.exp(-emitter_width * alpha)

    def fit_Isenberg(self, wavelength, IQE, theta, Plot=False, wlbounds=[700, 940]):
        '''
        Performs the fit using the Isenberg_function
        It is fitted by default between the wavelengths of 700 and 940.

        The fit uses a full analytical solution to the IQE, and is thus
        expected to provide the most accurate results. This is considered an improvement of the
        Basore method. The short wavelength side is reduced as a "dead" layer is placed
        at the front of the device.

        doi:10.1109/PVSC.2002.1190525

            returns:
                a dictionary containing
                    L: the diffusion length (cm)
                    Srear: and the rear surface
                           recombination velocity (cm/s)
                    WJ: width of the junction
        '''
        # print 'current does not work, unsure why'

        fitting_params = ['L', 'Srear', 'Wj']

        index = wavelength > wlbounds[0]
        index *= wavelength < wlbounds[1]

        IQE = IQE[index]
        wavelength = wavelength[index]

        alpha = self._wavelength2alpha(
            wavelength) / np.cos(np.radians(theta))

        p0 = (.09, 10000, 7.11561984e-06)
        fit_values, self.conv_matrix = optimize.curve_fit(
            self.Isenberg_function,
            alpha,
            IQE,
            p0=p0,
            method='trf',
            bounds=(0, [100, 1e6, 0.02])
            )

        if Plot:
            self._Plot_ialpha_iIQE(1. / alpha, 1. / IQE, 'ro')
            self._Plot_ialpha_iIQE(
                1. / alpha,
                1. / self.Isenberg_function(alpha, *fit_values),
                'r--',
                label='Isenberg')

        return {fitting_params[i]: fit_values[i]
                for i in range(len(fitting_params))}

    def fit_strongabsorption(self, wavelength, IQE, upper_bound=425, w=0.018, Plot=False):
        '''
        analysis from Lan2014.
        Fits to absorption depths > 1cm.
        There is an upper bound as parsidic absorption increase at longwavelength preventing analysis

        inputs:
            wavelength: is the wavelength
            IQE:        is the IQE
            upper_bound: is the upper bound in wavelength (defults is 1125)
            w:          (in cm)is the thickness, and used to determine the lower limit
                defult is .018
            Plot:        (bool), if true will plot cropped data and fit

        returns the collection efficiency, and the parsidic absorption coefficient
        '''

        # check to make sure IQE max is 1
        IQE = self._check_IQE(IQE)

        # get alpha
        alpha = self._wavelength2alpha(wavelength)

        # set lower bound
        lower_fraction = 7
        lower_bound = (w * lower_fraction)

        # fit
        m, b, inv_fitalpha, fitIQE = self._fit_invIQE_invalpha(1. / alpha,
                                                               IQE,
                                                               0,
                                                               1. /
                                                               self._wavelength2alpha(
                                                                   upper_bound),
                                                               )

        return m, b

    def RearJunctionDevice(self, wavelength, IQE):
        '''
        For a rear junction device,
        as outlined by D. Lan in Lan2015
        '''

        # do d lan's
        # print wavelength, IQE

        m, b = self.fit_weakabsorption(wavelength, IQE)

        collection = 100. / b
        parsidic = m / b

        # m, b = self.fit_strongabsorption(
        #     wavelength, IQE, upper_bound=600, Plot=True)

        # print wavelength, 1./ialpha

        return collection, parsidic
