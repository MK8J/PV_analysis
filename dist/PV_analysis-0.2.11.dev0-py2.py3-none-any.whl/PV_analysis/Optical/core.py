

from PV_analysis.common import IO
import numbers


def diff_sample_transmission(sample1, sample2):

    return sample1.trans - sample2.trans


class FTIR():

    sample = {
        'name': None,
        'doping': None,
        'thickness': None,
        'dopant': None,
        'optical_c': None,
        'temp': None,
        'V_t': None,
        'I_t': None,
        'area': None,
    }

    _trans_raw = None
    trans = None
    wavelength = None
    background = None
    fname = None

    def __init__(self, **kwargs):
        self.attr = kwargs
        pass

    def background_correct(self):
        if self._trans_raw is None:
            self._trans_raw = self.trans

        if self.background is not None:
            self.trans = self._trans_raw / self.background * 100


class photo_spec():

    sample = {
        'name': None,
        'doping': None,
        'thickness': None,
        'dopant': None,
        'optical_c': None,
        'temp': None,
        'V_t': None,
        'I_t': None,
        'area': None,
    }

    _trans_raw = None
    trans = None
    wavelength = None
    background = None
    fname = None

    def __init__(self, **kwargs):
        self.attr = kwargs
        pass

    def background_correct(self):
        if self._trans_raw is None:
            self._trans_raw = self.trans

        if self.background is not None:
            self.trans = self._trans_raw / self.background * 100
